1. Open the app.py file in your code editor
2. Start the server.
3. Click over the link provided
4. App will start